package com.thapelo.scorekeeper;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/*
 * This app Displays scores of a soccer match
 */
public class MainActivity extends AppCompatActivity {
    // Variable initialised for goals of Team One
    int pointTeamOne = 0;
    // Variable initialised for goals of Team Two
    int pointTeamTwo = 0;
    // Variable initialised for red cards issued to team One
    int redCardIssuedTeamOne = 0;
    //Variable initialised for red cards issued to team Two
    int redCardIssuedTeamTwo = 0;
    //Variable initialised for yellow cards issued to team One
    int yellowCardIssuedTeamOne = 0;
    //Variable initialised for yellow cards issued to team Two
    int yellowCardIssuedTeamTwo = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        /*
         * Call and initialise the media player object
         */
        Button one = this.findViewById( R.id.whistle_button );
        final MediaPlayer mp = MediaPlayer.create( this, R.raw.whistle );
        one.setOnClickListener( new View.OnClickListener() {
            @Override
            /*
             * This method plays a referee whistle.Resets goal scores,yellow cards and red card issued to both teams.
             */
            public void onClick(View view) {
                mp.start();
                pointTeamOne = 0;
                showGoalTeamOne( pointTeamOne );
                pointTeamTwo = 0;
                showGoalTeamTwo( pointTeamTwo );
                redCardIssuedTeamOne = 0;
                showRedCardTeamOne( redCardIssuedTeamOne );
                redCardIssuedTeamTwo = 0;
                showRedCardTeamTwo( redCardIssuedTeamTwo );
                yellowCardIssuedTeamOne = 0;
                showYellowCardTeamOne( yellowCardIssuedTeamOne );
                yellowCardIssuedTeamTwo = 0;
                showYellowCardTeamTwo( yellowCardIssuedTeamTwo );
            }
        } );
    }

    /*
     * This method displays a number of goals for team one
     */
    public void showGoalTeamOne(int number) {
        TextView text_view_point_team_one = findViewById( R.id.text_view_goal_team_one );
        text_view_point_team_one.setText( "" + number );
    }

    /*
     * This method Adds a Goal for team one
     */
    public void addGoalTeamOne(View view) {
        showGoalTeamOne( pointTeamOne + 1 );
        pointTeamOne = pointTeamOne + 1;
        showGoalTeamOne( pointTeamOne );
    }

    /*
     * This method minuses an off site Goal for team one
     */
    public void minusGoalTeamOne(View view) {
        // Disabling negative number
        if (pointTeamOne == 0) {
            // Toast message to show that you cant have a negative goal.
            Toast.makeText( this, "Goals cant be negated", Toast.LENGTH_SHORT ).show();
            return;

        }
        pointTeamOne = pointTeamOne - 1;
        showGoalTeamOne( pointTeamOne );
    }

    /*
     * This method displays the number of red cards for Team one
     */
    public void showRedCardTeamOne(int number) {
        TextView text_view_red_card_team_one = findViewById( R.id.text_view_red_card_team_one );
        text_view_red_card_team_one.setText( "" + number );
    }

    /*
     * This method adds the number of red card for team one
     */
    public void addRedCardTeamOne(View view) {
        redCardIssuedTeamOne = redCardIssuedTeamOne + 1;
        showRedCardTeamOne( redCardIssuedTeamOne );
    }

    /*
     * This method displays the number of yellow cards for Team one
     */
    public void showYellowCardTeamOne(int number) {
        TextView text_view_yellow_card_team_one = findViewById( R.id.text_view_yellow_card_team_one );
        text_view_yellow_card_team_one.setText( "" + number );
    }

    /*
     * This method adds the number of yellow card for team one
     */
    public void addYellowCardTeamOne(View view) {
        yellowCardIssuedTeamOne = yellowCardIssuedTeamOne + 1;
        showYellowCardTeamOne( yellowCardIssuedTeamOne );
    }

    /*
     * This method displays a number of goals for team two
     */
    public void showGoalTeamTwo(int number) {
        TextView text_view_point_team_two = findViewById( R.id.text_view_goal_team_two );
        text_view_point_team_two.setText( "" + number );
    }

    /*
     * This method Adds a Goal for team two
     */
    public void addGoalTeamTwo(View view) {
        showGoalTeamTwo( pointTeamTwo + 1 );
        pointTeamTwo = pointTeamTwo + 1;
        showGoalTeamTwo( pointTeamTwo );
    }

    /*
     * This method minuses an off site Goal for team two
     */
    public void minusGoalTeamTwo(View view) {
        // Disabling negative number
        if (pointTeamTwo == 0) {
            // Toast message to show that you cant have a negative goal.
            Toast.makeText( this, "Goals cant be negated", Toast.LENGTH_SHORT ).show();
            return;

        }
        pointTeamTwo = pointTeamTwo - 1;
        showGoalTeamTwo( pointTeamTwo );
    }
    /*
     * This method displays the number of red cards for Team two
     */

    public void showRedCardTeamTwo(int number) {
        TextView text_view_red_card_team_two = findViewById( R.id.text_view_red_card_team_two );
        text_view_red_card_team_two.setText( "" + number );
    }
    /*
     * This method adds the number of red card for team two
     */

    public void addRedCardTeamTwo(View view) {
        redCardIssuedTeamTwo = redCardIssuedTeamTwo + 1;
        showRedCardTeamTwo( redCardIssuedTeamTwo );
    }

    /*
     * This method displays the number of yellow cards for Team two
     */
    public void showYellowCardTeamTwo(int number) {
        TextView text_view_yellow_card_team_two = findViewById( R.id.text_view_yellow_card_team_two );
        text_view_yellow_card_team_two.setText( "" + number );
    }

    /*
     * This method adds the number of yellow cards for team two
     */
    public void addYellowCardTeamTwo(View view) {
        yellowCardIssuedTeamTwo = yellowCardIssuedTeamTwo + 1;
        showYellowCardTeamTwo( yellowCardIssuedTeamTwo );
    }
}